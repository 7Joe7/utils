class HelloController < ApplicationController
  def home
  end
end
